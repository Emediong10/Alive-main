@include('layouts.app')
@include('layouts.nav')

<livewire:counter/>
@livewireScripts()

