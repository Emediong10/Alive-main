<header id="header" class="header-size-custom" data-sticky-shrink="true">
			<div id="header-wrap">
				<div class="container">
					<div class="header-row">

						<!-- Logo
						============================================= -->
						<div id="logo">
							<a href="{{ url('/') }}" class="standard-logo"><img src="{{ url('assets/images/Aliveng.png') }}" alt="Alive Logo"></a>
						 </div><!-- #logo end -->


						

						<!-- Primary Navigation
						============================================= -->
						<nav class="primary-menu">


						</nav><!-- #primary-menu end -->
{{-- 
						<form class="top-search-form" action="search.html" method="get">
							<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter.." autocomplete="off">
						</form> --}}

					</div>
				</div>
			</div>
			<div class="header-wrap-clone"></div>
		</header><!-- #header end -->