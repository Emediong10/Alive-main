@include('layouts.app')
@include('layouts.nav')
<livewire:wizard/>
@livewireScripts()
